﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor
{
    class ECG :PhysioParameter 
    {
       public ECG (double amplitude, double frequency , int harmonics) : base(amplitude, frequency, harmonics) { }
    


    public double NextSample(double timeIndex)
        {
            const double HzToBeatsPerMin = 150.0;
            double sample = 0;

            switch (harmonics)
            {
                case 1:
                    sample = Math.Cos(2 * Math.PI * (frequency / HzToBeatsPerMin) * timeIndex);
                    break;
                case 2:
                    sample = Math.Cos(2 * Math.PI * (frequency / HzToBeatsPerMin) * timeIndex) + 0.5 * Math.Cos(2 * Math.PI * (2 * frequency / HzToBeatsPerMin) * timeIndex);
                    break;
                case 3:
                    sample = Math.Cos(2 * Math.PI * (frequency / HzToBeatsPerMin) * timeIndex) + 0.5 * Math.Cos(2 * Math.PI * (2 * frequency / HzToBeatsPerMin) * timeIndex) + 0.25 * Math.Cos(2 * Math.PI * (3 * frequency / HzToBeatsPerMin) * timeIndex);
                    break;

            }

            sample *= amplitude;

            return (sample);
        }
    }
}

