﻿using System;

namespace PatientMonitor
{
    class Resp : PhysioParameter
    {
        public Resp(double amplitude, double frequency, int harmonics) : base(amplitude, frequency, harmonics) { }

        public double NextSample(double timeIndex)
        {
            const double HzToBeatsPerMin = 30.0;
            double sample = 0.0;

            // Berechnung der Signallänge basierend auf der Frequenz und HzToBeatsPerMin
            double SignalLength = HzToBeatsPerMin / (frequency / 10);

            // Berechnung des Zeitwerts innerhalb der aktuellen Signallänge
            double stepIndex = (timeIndex * 0.025) % SignalLength;

            // Berechnung des Signals basierend auf der Position in der Signallänge
            
            if (stepIndex < HzToBeatsPerMin / 2) { 
                // Erste Hälfte der Signallänge: aufsteigende Rampe von 0 bis Amplitude
                sample = (amplitude * (2 * stepIndex / SignalLength));
        }
       else
            // Zweite Hälfte der Signallänge: abfallende Rampe von Amplitude bis 0
        sample = 0;
               
            

            return sample;
        }
    }
}
