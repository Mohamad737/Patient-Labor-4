﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor
{
    class PhysioParameter
    {
        protected double amplitude = 0.0;
        protected double frequency = 0.0;

        protected int harmonics = 0;

        public double Amplitude { get => amplitude; set => amplitude = value; }
        public double Frequency { get => frequency; set => frequency = value; }
        public int Harmonics { get => harmonics; set => harmonics = value; }

        public PhysioParameter(double amplitude, double frequency, int harmonics)
        {
            {
                this.amplitude = amplitude;
                this.frequency = frequency;
                this.harmonics = harmonics;
            }
        }







    }
}
