﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor
{
    class EEG : PhysioParameter
    {
 public EEG ( double amplitude , double frequency , int harmonics) :base (amplitude , frequency , harmonics) { }



    

    public double NextSample(double timeIndex)
        {
            const double HzToBeatsPerMin = 150.0;
            double sample = 0.0;

            // Berechnung der Signallänge basierend auf der Frequenz und HzToBeatsPerMin
            double SignalLength = HzToBeatsPerMin / frequency;

            // Zeitwert innerhalb der aktuellen Signallänge
            double stepIndex = (timeIndex * 0.025) % SignalLength;

            // Berechnung des Signals basierend auf der Position in der Signallänge
            if (stepIndex < SignalLength / 2)
            {
                // Erste Hälfte der Signallänge: gespiegelte exponentielle Abnahme
                sample = -amplitude * (Math.Exp(-5 * stepIndex / (SignalLength / 2)) - 1);
            }
            else
            {
                // Zweite Hälfte der Signallänge: normale exponentielle Abnahme
                sample = amplitude * (Math.Exp(-5 * (stepIndex - SignalLength / 2) / (SignalLength / 2)) - 1);
            }

            return sample;
        }




    }
}
